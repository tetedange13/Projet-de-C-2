    
    PROJET DE PROGRAMMATION EN C;   Felix VANDERMEEREN & Thomas BERSEZ
        
        ----------------------------------------------------------
        -Genération aléotoire de labyrinthe et projection en 2.5D-
        ----------------------------------------------------------
    
        Pour tester notre projet :
            $ ./compile.sh
            $ ./a.out
     
    Vous pouvez ensuite vous déplacer à l'aide des flèches directionnelles.
      
